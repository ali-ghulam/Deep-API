# -*- coding: utf-8 -*-
"""
Created on Feb 15 14:01:53 2026

@author: aghul
"""


import torch
import torch.nn as nn


class CNNClassifier(nn.Module):
    def __init__(self, vocab_size=21, embed_dim=32, num_filters=64, kernel_sizes=(3, 5, 7), dropout=0.3):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv1d(embed_dim, num_filters, k) for k in kernel_sizes
        ])
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(num_filters * len(kernel_sizes), 1)

    def forward(self, x):
        x = self.embedding(x)              # [B, L, E]
        x = x.transpose(1, 2)             # [B, E, L]
        feats = []
        for conv in self.convs:
            z = torch.relu(conv(x))
            z = torch.max(z, dim=2).values
            feats.append(z)
        out = torch.cat(feats, dim=1)
        out = self.dropout(out)
        return self.fc(out).squeeze(1)


class BiLSTMClassifier(nn.Module):
    def __init__(self, vocab_size=21, embed_dim=32, hidden_dim=64, num_layers=1, dropout=0.3):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.lstm = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim * 2, 1)

    def forward(self, x):
        x = self.embedding(x)
        out, _ = self.lstm(x)
        pooled = out.mean(dim=1)
        pooled = self.dropout(pooled)
        return self.fc(pooled).squeeze(1)


class FeatureMLP(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, dropout=0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(1)


def ensemble_average(*prob_arrays):
    import numpy as np
    stacked = np.vstack(prob_arrays)
    return stacked.mean(axis=0)
