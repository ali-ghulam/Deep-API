# -*- coding: utf-8 -*-
"""
Created on Feb 18 10:05:23 2026

@author: aghul
"""



import copy
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader


def run_epoch(model, loader, optimizer, device, train=True):
    criterion = nn.BCEWithLogitsLoss()
    if train:
        model.train()
    else:
        model.eval()

    total_loss = 0.0
    all_ids, all_probs, all_labels = [], [], []

    for batch in loader:
        x, y, ids = batch
        x = x.to(device)
        y = y.to(device)

        with torch.set_grad_enabled(train):
            logits = model(x)
            loss = criterion(logits, y)

            if train:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        probs = torch.sigmoid(logits).detach().cpu().numpy()
        labels = y.detach().cpu().numpy()

        total_loss += loss.item() * len(labels)
        all_probs.extend(probs.tolist())
        all_labels.extend(labels.tolist())
        all_ids.extend(list(ids))

    avg_loss = total_loss / max(len(all_labels), 1)
    return avg_loss, np.array(all_labels), np.array(all_probs), all_ids


def run_epoch_features(model, loader, optimizer, device, train=True):
    criterion = nn.BCEWithLogitsLoss()
    if train:
        model.train()
    else:
        model.eval()

    total_loss = 0.0
    all_ids, all_probs, all_labels = [], [], []

    for batch in loader:
        x, y, ids = batch
        x = x.to(device)
        y = y.to(device)

        with torch.set_grad_enabled(train):
            logits = model(x)
            loss = criterion(logits, y)

            if train:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        probs = torch.sigmoid(logits).detach().cpu().numpy()
        labels = y.detach().cpu().numpy()

        total_loss += loss.item() * len(labels)
        all_probs.extend(probs.tolist())
        all_labels.extend(labels.tolist())
        all_ids.extend(list(ids))

    avg_loss = total_loss / max(len(all_labels), 1)
    return avg_loss, np.array(all_labels), np.array(all_probs), all_ids


def fit_model(model, train_loader, valid_loader, device, epochs=10, lr=1e-3, feature_mode=False):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    best_state = None
    best_val_loss = float("inf")
    history = []

    for epoch in range(1, epochs + 1):
        if feature_mode:
            tr_loss, _, _, _ = run_epoch_features(model, train_loader, optimizer, device, train=True)
            va_loss, va_y, va_p, va_ids = run_epoch_features(model, valid_loader, optimizer, device, train=False)
        else:
            tr_loss, _, _, _ = run_epoch(model, train_loader, optimizer, device, train=True)
            va_loss, va_y, va_p, va_ids = run_epoch(model, valid_loader, optimizer, device, train=False)

        history.append({"epoch": epoch, "train_loss": tr_loss, "valid_loss": va_loss})

        if va_loss < best_val_loss:
            best_val_loss = va_loss
            best_state = copy.deepcopy(model.state_dict())

    if best_state is not None:
        model.load_state_dict(best_state)
    return model, pd.DataFrame(history)


def predict_model(model, loader, device, feature_mode=False):
    if feature_mode:
        _, y, p, ids = run_epoch_features(model, loader, optimizer=None, device=device, train=False)
    else:
        _, y, p, ids = run_epoch(model, loader, optimizer=None, device=device, train=False)
    return y, p, ids
