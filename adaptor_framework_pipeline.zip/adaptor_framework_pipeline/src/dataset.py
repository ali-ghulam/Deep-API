# -*- coding: utf-8 -*-
"""
Created on Feb 15 20:05:58 2026

@author: aghul
"""


import numpy as np
import torch
from torch.utils.data import Dataset
from data_utils import encode_sequence


class SequenceDataset(Dataset):
    def __init__(self, rows, max_len=1000):
        self.rows = rows
        self.max_len = max_len

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        row = self.rows[idx]
        x = torch.tensor(encode_sequence(row["sequence"], self.max_len), dtype=torch.long)
        y = torch.tensor(row["label"], dtype=torch.float32)
        return x, y, row["protein_id"]


class FeatureDataset(Dataset):
    def __init__(self, feature_df):
        self.df = feature_df.copy()
        self.labels = self.df["label"].astype(float).values
        self.ids = self.df["protein_id"].astype(str).values
        self.X = self.df.drop(columns=["protein_id", "label"]).replace({np.nan: 0.0}).astype(float).values

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        x = torch.tensor(self.X[idx], dtype=torch.float32)
        y = torch.tensor(self.labels[idx], dtype=torch.float32)
        return x, y, self.ids[idx]
