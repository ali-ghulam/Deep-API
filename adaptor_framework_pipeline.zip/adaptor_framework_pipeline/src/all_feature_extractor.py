# -*- coding: utf-8 -*-
"""
Created on  Feb 10 09:33:22 2026

@author: aghul
"""


#!/usr/bin/env python3
"""
all_feature_extractor.py

Extracts:
1) GAAC features directly from FASTA sequences
2) PSSM composition features from ASCII .pssm files
3) CST-PSSM features from ASCII .pssm files

Notes:
- GAAC works directly from FASTA sequences.
- True PSSM and CST-PSSM require PSI-BLAST-generated ASCII .pssm files.
- Expected PSSM filenames: <protein_id>.pssm
"""

from pathlib import Path
import argparse
import pandas as pd
import numpy as np

AA_ORDER = list("ACDEFGHIKLMNPQRSTVWY")
AA_SET = set(AA_ORDER)

GAAC_GROUPS = {
    "gaac_aliphatic": set("GAVLMI"),
    "gaac_aromatic": set("FYW"),
    "gaac_positive": set("KRH"),
    "gaac_negative": set("DE"),
    "gaac_uncharged": set("STCPNQ"),
}


def parse_fasta(path: Path):
    records = []
    seq_id = None
    chunks = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if seq_id is not None:
                    records.append((seq_id, "".join(chunks)))
                seq_id = line[1:].strip()
                chunks = []
            else:
                chunks.append(line.upper())
        if seq_id is not None:
            records.append((seq_id, "".join(chunks)))
    return records


def clean_sequence(seq: str) -> str:
    return "".join(ch for ch in seq if ch in AA_SET)


def gaac_features(seq: str):
    L = len(seq) or 1
    out = {}
    for name, grp in GAAC_GROUPS.items():
        out[name] = sum(1 for ch in seq if ch in grp) / L
    return out


def read_ascii_pssm(pssm_path: Path) -> np.ndarray:
    """
    Parses standard PSI-BLAST ASCII PSSM format.
    Returns matrix of shape (L, 20).
    """
    rows = []
    started = False

    with open(pssm_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.strip().split()

            # Standard ASCII PSSM rows عادة ایسے ہوتے ہیں:
            # idx residue 20_scores ...
            if len(parts) >= 22 and parts[0].isdigit():
                try:
                    scores = [float(x) for x in parts[2:22]]
                    rows.append(scores)
                    started = True
                except ValueError:
                    continue
            elif started and not parts:
                break

    if not rows:
        raise ValueError(f"No valid PSSM rows parsed from {pssm_path}")

    return np.asarray(rows, dtype=float)


def pssm_composition(M: np.ndarray) -> np.ndarray:
    return M.mean(axis=0)


def cst_pssm(M: np.ndarray, k: int = 1) -> np.ndarray:
    """
    CST-PSSM:
    For each amino-acid pair (i, j), compute average product of
    PSSM[t, i] * PSSM[t+k, j]
    """
    L, d = M.shape
    if L <= k:
        return np.zeros(d * d, dtype=float)

    feats = []
    for i in range(d):
        for j in range(d):
            feats.append(float(np.mean(M[:L-k, i] * M[k:, j])))
    return np.asarray(feats, dtype=float)


def build_feature_row(protein_id: str, seq: str, pssm_dir: Path = None, k: int = 1):
    clean_seq = clean_sequence(seq)
    row = {
        "protein_id": protein_id,
        "sequence_length": len(clean_seq),
    }

    # GAAC
    row.update(gaac_features(clean_seq))

    # PSSM + CST-PSSM
    if pssm_dir is not None:
        pssm_file = pssm_dir / f"{protein_id}.pssm"
        if pssm_file.exists():
            M = read_ascii_pssm(pssm_file)

            comp = pssm_composition(M)
            for aa, val in zip(AA_ORDER, comp):
                row[f"pssm_comp_{aa}"] = float(val)

            cst = cst_pssm(M, k=k)
            idx = 0
            for aa1 in AA_ORDER:
                for aa2 in AA_ORDER:
                    row[f"cstpssm_k{k}_{aa1}_{aa2}"] = float(cst[idx])
                    idx += 1
        else:
            for aa in AA_ORDER:
                row[f"pssm_comp_{aa}"] = np.nan
            for aa1 in AA_ORDER:
                for aa2 in AA_ORDER:
                    row[f"cstpssm_k{k}_{aa1}_{aa2}"] = np.nan
    return row


def extract_all_features(fasta_path: Path, out_csv: Path, pssm_dir: Path = None, k: int = 1):
    rows = []
    missing_pssm = 0

    for protein_id, seq in parse_fasta(fasta_path):
        row = build_feature_row(protein_id, seq, pssm_dir=pssm_dir, k=k)
        if pssm_dir is not None and pd.isna(row.get("pssm_comp_A", np.nan)):
            missing_pssm += 1
        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(out_csv, index=False)

    print(f"Wrote {len(df)} rows to {out_csv}")
    if pssm_dir is not None:
        print(f"Proteins without matching .pssm file: {missing_pssm}")


def main():
    parser = argparse.ArgumentParser(
        description="Extract GAAC + PSSM + CST-PSSM features from FASTA and optional PSSM files"
    )
    parser.add_argument("--fasta", required=True, help="Input FASTA file")
    parser.add_argument("--out_csv", required=True, help="Output CSV path")
    parser.add_argument("--pssm_dir", default=None, help="Directory containing ASCII .pssm files")
    parser.add_argument("--k", type=int, default=1, help="Gap parameter for CST-PSSM")
    args = parser.parse_args()

    fasta_path = Path(args.fasta)
    out_csv = Path(args.out_csv)
    pssm_dir = Path(args.pssm_dir) if args.pssm_dir else None

    extract_all_features(
        fasta_path=fasta_path,
        out_csv=out_csv,
        pssm_dir=pssm_dir,
        k=args.k,
    )


if __name__ == "__main__":
    main()
