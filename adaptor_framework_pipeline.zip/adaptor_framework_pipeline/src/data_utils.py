# -*- coding: utf-8 -*-
"""
Created on Feb 15 21:05:58 2026

@author: aghul
"""


from pathlib import Path
from typing import List, Tuple, Dict
import random

AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
AA_TO_IDX = {aa: i + 1 for i, aa in enumerate(AA_ORDER)}  # 0 for padding/unknown


def parse_fasta(path: str) -> List[Tuple[str, str]]:
    records = []
    seq_id = None
    chunks = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if seq_id is not None:
                    records.append((seq_id, "".join(chunks).upper()))
                seq_id = line[1:].strip()
                chunks = []
            else:
                chunks.append(line)
        if seq_id is not None:
            records.append((seq_id, "".join(chunks).upper()))
    return records


def clean_sequence(seq: str) -> str:
    return "".join(ch for ch in seq if ch in AA_ORDER)


def encode_sequence(seq: str, max_len: int) -> List[int]:
    seq = clean_sequence(seq)
    arr = [AA_TO_IDX.get(ch, 0) for ch in seq[:max_len]]
    if len(arr) < max_len:
        arr += [0] * (max_len - len(arr))
    return arr


def load_labeled_fasta_files(class_files: Dict[int, List[str]]):
    rows = []
    for label, paths in class_files.items():
        for path in paths:
            for protein_id, seq in parse_fasta(path):
                rows.append({
                    "protein_id": protein_id,
                    "sequence": clean_sequence(seq),
                    "label": int(label),
                    "source_file": str(path),
                })
    return rows


def train_valid_split(rows, valid_ratio=0.2, seed=42):
    rng = random.Random(seed)
    rows = rows[:]
    rng.shuffle(rows)
    n_valid = int(len(rows) * valid_ratio)
    valid = rows[:n_valid]
    train = rows[n_valid:]
    return train, valid
