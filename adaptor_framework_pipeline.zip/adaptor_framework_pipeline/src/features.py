# -*- coding: utf-8 -*-
"""
Created on Feb 08 13:05:58 2026

@author: aghul
"""



from pathlib import Path
import numpy as np
import pandas as pd

AA_ORDER = list("ACDEFGHIKLMNPQRSTVWY")
AA_SET = set(AA_ORDER)

GAAC_GROUPS = {
    "gaac_aliphatic": set("GAVLMI"),
    "gaac_aromatic": set("FYW"),
    "gaac_positive": set("KRH"),
    "gaac_negative": set("DE"),
    "gaac_uncharged": set("STCPNQ"),
}


def gaac_features(seq: str):
    seq = "".join(ch for ch in seq if ch in AA_SET)
    L = len(seq) or 1
    return {k: sum(1 for ch in seq if ch in grp) / L for k, grp in GAAC_GROUPS.items()}


def read_ascii_pssm(pssm_path: Path) -> np.ndarray:
    rows = []
    started = False
    with open(pssm_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 22 and parts[0].isdigit():
                try:
                    vals = [float(x) for x in parts[2:22]]
                    rows.append(vals)
                    started = True
                except ValueError:
                    continue
            elif started and not parts:
                break
    if not rows:
        raise ValueError(f"No valid PSSM rows parsed from {pssm_path}")
    return np.asarray(rows, dtype=float)


def pssm_composition(M: np.ndarray) -> np.ndarray:
    return M.mean(axis=0)


def cst_pssm(M: np.ndarray, k: int = 1) -> np.ndarray:
    L, d = M.shape
    if L <= k:
        return np.zeros(d * d, dtype=float)
    feats = []
    for i in range(d):
        for j in range(d):
            feats.append(float(np.mean(M[:L-k, i] * M[k:, j])))
    return np.asarray(feats, dtype=float)


def build_feature_row(protein_id: str, sequence: str, pssm_dir: str = None, k: int = 1):
    row = {"protein_id": protein_id}
    row.update(gaac_features(sequence))

    # Fill default NaNs
    for aa in AA_ORDER:
        row[f"pssm_comp_{aa}"] = np.nan
    for aa1 in AA_ORDER:
        for aa2 in AA_ORDER:
            row[f"cstpssm_k{k}_{aa1}_{aa2}"] = np.nan

    if pssm_dir:
        pssm_file = Path(pssm_dir) / f"{protein_id}.pssm"
        if pssm_file.exists():
            M = read_ascii_pssm(pssm_file)
            comp = pssm_composition(M)
            for aa, val in zip(AA_ORDER, comp):
                row[f"pssm_comp_{aa}"] = float(val)
            cst = cst_pssm(M, k=k)
            idx = 0
            for aa1 in AA_ORDER:
                for aa2 in AA_ORDER:
                    row[f"cstpssm_k{k}_{aa1}_{aa2}"] = float(cst[idx])
                    idx += 1
    return row


def build_feature_dataframe(rows, pssm_dir=None, k=1):
    feats = []
    for row in rows:
        fr = build_feature_row(row["protein_id"], row["sequence"], pssm_dir=pssm_dir, k=k)
        fr["label"] = row["label"]
        feats.append(fr)
    return pd.DataFrame(feats)
