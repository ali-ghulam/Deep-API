# -*- coding: utf-8 -*-
"""
Created on Feb 15 15:09:12 2026

@author: aghul
"""



from pathlib import Path
import argparse
import json
import pandas as pd
import torch
from torch.utils.data import DataLoader

from data_utils import load_labeled_fasta_files, train_valid_split
from features import build_feature_dataframe
from dataset import SequenceDataset, FeatureDataset
from models import CNNClassifier, BiLSTMClassifier, FeatureMLP, ensemble_average
from train_utils import fit_model, predict_model
from metrics import compute_metrics, save_metrics


def save_predictions(ids, y_true, y_prob, out_path):
    pd.DataFrame({
        "protein_id": ids,
        "y_true": y_true,
        "y_prob": y_prob,
        "y_pred": (y_prob >= 0.5).astype(int),
    }).to_csv(out_path, index=False)


def main():
    ap = argparse.ArgumentParser(description="Framework-based adaptor protein pipeline")
    ap.add_argument("--pos_train", nargs="+", default=None, help="Positive-class train FASTA file(s)")
    ap.add_argument("--neg_train", nargs="+", default=None, help="Negative-class train FASTA file(s)")
    ap.add_argument("--pos_test", nargs="+", default=None, help="Positive-class test FASTA file(s)")
    ap.add_argument("--neg_test", nargs="+", default=None, help="Negative-class test FASTA file(s)")
    ap.add_argument("--pssm_dir", default=None, help="Directory with .pssm files")
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--max_len", type=int, default=1000)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--valid_ratio", type=float, default=0.2)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    if not args.pos_train or not args.neg_train or not args.pos_test or not args.neg_test:
        raise ValueError("Please provide --pos_train --neg_train --pos_test --neg_test FASTA files.")

    train_rows = load_labeled_fasta_files({
        1: args.pos_train,
        0: args.neg_train,
    })
    test_rows = load_labeled_fasta_files({
        1: args.pos_test,
        0: args.neg_test,
    })
    train_rows, valid_rows = train_valid_split(train_rows, valid_ratio=args.valid_ratio, seed=42)

    # Sequence datasets
    train_seq_ds = SequenceDataset(train_rows, max_len=args.max_len)
    valid_seq_ds = SequenceDataset(valid_rows, max_len=args.max_len)
    test_seq_ds = SequenceDataset(test_rows, max_len=args.max_len)

    train_seq_loader = DataLoader(train_seq_ds, batch_size=args.batch_size, shuffle=True)
    valid_seq_loader = DataLoader(valid_seq_ds, batch_size=args.batch_size, shuffle=False)
    test_seq_loader = DataLoader(test_seq_ds, batch_size=args.batch_size, shuffle=False)

    device = torch.device(args.device)

    # CNN
    cnn = CNNClassifier().to(device)
    cnn, hist_cnn = fit_model(cnn, train_seq_loader, valid_seq_loader, device=device, epochs=args.epochs, lr=args.lr)
    hist_cnn.to_csv(outdir / "history_cnn.csv", index=False)
    torch.save(cnn.state_dict(), outdir / "cnn_model.pt")

    y_test_cnn, p_test_cnn, ids_test = predict_model(cnn, test_seq_loader, device=device)
    m_cnn = compute_metrics(y_test_cnn, p_test_cnn)
    save_metrics(m_cnn, outdir / "metrics_cnn.json")
    save_predictions(ids_test, y_test_cnn, p_test_cnn, outdir / "predictions_cnn.csv")

    # BiLSTM
    bilstm = BiLSTMClassifier().to(device)
    bilstm, hist_bilstm = fit_model(bilstm, train_seq_loader, valid_seq_loader, device=device, epochs=args.epochs, lr=args.lr)
    hist_bilstm.to_csv(outdir / "history_bilstm.csv", index=False)
    torch.save(bilstm.state_dict(), outdir / "bilstm_model.pt")

    y_test_bilstm, p_test_bilstm, ids_test2 = predict_model(bilstm, test_seq_loader, device=device)
    m_bilstm = compute_metrics(y_test_bilstm, p_test_bilstm)
    save_metrics(m_bilstm, outdir / "metrics_bilstm.json")
    save_predictions(ids_test2, y_test_bilstm, p_test_bilstm, outdir / "predictions_bilstm.csv")

    # Feature extraction: GAAC + optional PSSM + optional CST-PSSM
    train_feat_df = build_feature_dataframe(train_rows, pssm_dir=args.pssm_dir, k=1)
    valid_feat_df = build_feature_dataframe(valid_rows, pssm_dir=args.pssm_dir, k=1)
    test_feat_df = build_feature_dataframe(test_rows, pssm_dir=args.pssm_dir, k=1)

    train_feat_df.to_csv(outdir / "train_features.csv", index=False)
    valid_feat_df.to_csv(outdir / "valid_features.csv", index=False)
    test_feat_df.to_csv(outdir / "test_features.csv", index=False)

    # Optional MLP on handcrafted features
    train_feat_ds = FeatureDataset(train_feat_df)
    valid_feat_ds = FeatureDataset(valid_feat_df)
    test_feat_ds = FeatureDataset(test_feat_df)

    train_feat_loader = DataLoader(train_feat_ds, batch_size=args.batch_size, shuffle=True)
    valid_feat_loader = DataLoader(valid_feat_ds, batch_size=args.batch_size, shuffle=False)
    test_feat_loader = DataLoader(test_feat_ds, batch_size=args.batch_size, shuffle=False)

    input_dim = train_feat_ds.X.shape[1]
    mlp = FeatureMLP(input_dim=input_dim).to(device)
    mlp, hist_mlp = fit_model(mlp, train_feat_loader, valid_feat_loader, device=device, epochs=args.epochs, lr=args.lr, feature_mode=True)
    hist_mlp.to_csv(outdir / "history_mlp.csv", index=False)
    torch.save(mlp.state_dict(), outdir / "mlp_feature_model.pt")

    y_test_mlp, p_test_mlp, ids_test3 = predict_model(mlp, test_feat_loader, device=device, feature_mode=True)
    m_mlp = compute_metrics(y_test_mlp, p_test_mlp)
    save_metrics(m_mlp, outdir / "metrics_mlp_features.json")
    save_predictions(ids_test3, y_test_mlp, p_test_mlp, outdir / "predictions_mlp_features.csv")

    # Ensemble
    p_ens = ensemble_average(p_test_cnn, p_test_bilstm, p_test_mlp)
    m_ens = compute_metrics(y_test_cnn, p_ens)
    save_metrics(m_ens, outdir / "metrics_ensemble.json")
    save_predictions(ids_test, y_test_cnn, p_ens, outdir / "predictions_ensemble.csv")

    summary = {
        "train_size": len(train_rows),
        "valid_size": len(valid_rows),
        "test_size": len(test_rows),
        "device": str(device),
        "pssm_dir_used": args.pssm_dir,
        "note": "GAAC is always computed. PSSM/CST-PSSM are filled when matching .pssm files exist.",
    }
    with open(outdir / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print("Pipeline completed successfully.")
    print(f"Outputs saved to: {outdir}")


if __name__ == "__main__":
    main()
